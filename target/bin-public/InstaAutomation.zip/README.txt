Catatan :
1. Jika sistem operasi anda Windows, ektstrak file chromedriver_win32.zip.

2. Jika sistem operasi anda Linux, ekstrak file chromedriver_linux64.zip

3. Jika sistem operasi anda Mac, ekstrak file chromedriver_mac64.zip

-->Jika sudah diekstrak jangan rename nama filenya, agar InstaAutomation dapat menemukannya dan bisa berjalan sebagaimana mestinya.
